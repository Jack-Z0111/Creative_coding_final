2D shooter game
(idea inspired by <Space Invader>)

Concept:
A spaceship(player) encounters a large group of asteroids and an alien jet.
People have to destroy the asteroid and dodge attacks from the enemy to survive.

Interactive shooting game.